# StudyQuest — Class 9 ICSE

A standalone-capable Progressive Web App (PWA) for personal study. It includes daily quests, flashcards, revision scheduling, focus timer, notes, XP/streaks, and JSON backup/import.

## Files
- `index.html` — app interface and styling
- `app.js` — app logic and local data persistence
- `manifest.webmanifest` — install metadata
- `sw.js` — offline shell cache
- `icon.svg`, `icon-192.png`, `icon-512.png` — app icons

## Run locally
Service workers and PWA installation need HTTPS or localhost (opening `index.html` directly is fine for a basic test, but offline install support will not activate).
1. Install Python 3.
2. In this folder, run: `python -m http.server 8000`
3. Open `http://localhost:8000` in your browser.

## Install on Android
1. Host the files on an HTTPS static host (for example, a static-site service or your own hosting).
2. Open the published URL in Chrome on Android.
3. Open Chrome's menu and choose **Install app** or **Add to Home screen**.
4. Launch StudyQuest from the home-screen icon. Once the app shell has cached, its main interface can open offline.

## Install on desktop
Open the HTTPS URL in a supported browser. Use the install icon in the address bar or the browser menu's install option when offered.

## Data and backups
App data is stored locally in the browser on each device. It does not automatically sync between devices. Use **Data → Export backup** on one device and **Import backup** on the other. Export backups regularly, especially before clearing browser data.

## Notes
- No login, analytics, or external services are used.
- The first flashcards and quests are examples; edit them to match your actual syllabus and workload.
- A static PWA is not a Play Store APK. Play Store publication or a native APK would require a separate packaging/signing workflow.
